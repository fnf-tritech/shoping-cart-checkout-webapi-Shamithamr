﻿namespace WebApplication4.Models
{
    public class Item
    {
        public char SKU { get; set; }
        public decimal Price { get; set; }
        public Offer Offer { get; set; }
    }
}
